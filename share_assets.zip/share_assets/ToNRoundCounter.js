function OnEvent(args) {
    if (args.Type == 'TERRORS') {
        WS.SendEvent("InstancePlayersCount", TON.StatsLobby.PlayersOnline);
    }
}
export { OnEvent };